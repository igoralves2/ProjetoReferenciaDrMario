#pragma once
#include "No.h"
template <class E>
class Pilha {
public:
	Pilha();
	~Pilha();
	int quantidadeElementos();
	void empilhar(E dado);
	void desenpilhar();
	bool estaVazia();
	E topoDaFila();
protected:
	No<E>* inicio;
	No<E>* fim;
	int count;
};

template<class E>
inline Pilha<E>::Pilha()
{
	inicio = nullptr;
	fim = nullptr;
	count = 0;
}

template<class E>
inline Pilha<E>::~Pilha()
{
}

template<class E>
inline int Pilha<E>::quantidadeElementos()
{
	return count;
}

template<class E>
inline void Pilha<E>::empilhar(E dado)
{
	No<E>* novo = new No<E>;
	novo->defineDado(dado);
	if (!estaVazia()) {
		fim->defineProximo(novo);
		fim = novo;
	}
	else {
		inicio = novo;
		fim = novo;
	}
	count++;
}

template<class E>
inline void Pilha<E>::desenpilhar()
{
	if (!estaVazia()) {
		if (count == 1) {
			inicio = nullptr;
			fim = nullptr;
		}
		else if (count == 2) {
			fim = inicio;
			No<E>* aux = fim->getProximo();
			delete aux;
		}
		else {
			No<E>* aux = inicio;
			for (int i = 0; i < count - 2; i++) {
				aux = aux->getProximo();
			}
			fim = aux;
			aux = fim->getProximo();
			delete aux;
		}
		count--;
	}
}

template<class E>
inline bool Pilha<E>::estaVazia()
{
	return count == 0;
}

template<class E>
inline E Pilha<E>::topoDaFila()
{
	return fim->getDado();
}
