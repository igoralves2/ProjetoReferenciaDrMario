#include "BlueVirus.h"

BlueVirus::BlueVirus()
{
	setClasseVirus(5);
	setSprite("bluevirus");
	setFeverPower(10);
	setChillPower(7);
	setCoughPower(9);
	setSneezePower(8);
	setAcuracy(10);
}
