#include "PurpleVirus.h"

PurpleVirus::PurpleVirus()
{
	setClasseVirus(6);
	setSprite("purplevirus");
	setFeverPower(8);
	setChillPower(12);
	setCoughPower(7);
	setSneezePower(9);
	setAcuracy(10);
}
