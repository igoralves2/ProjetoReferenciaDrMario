#include "TelaCarregarJogo.h"

TelaCarregarJogo::TelaCarregarJogo()
{
    setTipo(5);
    t.setFonte("supermario256");
    t.setCor(0, 0, 0);
    string s = "File select:\n";
    for (int i = 0; i < 3; i++) {
        s += to_string(i + 1) + ": Empty\n";
    }
    t.setString(s);
    t.setEscalaX(1);
    t.setEscalaY(1);
    t.setAlinhamento(TEXTO_CENTRALIZADO);
}

void TelaCarregarJogo::executar(Player *p, string nomes[5], long scorelist[5], ArrayList<Usuario> *uc)
{
	t.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 4);
}
