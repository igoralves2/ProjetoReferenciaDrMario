#pragma once
#include "Mascara.h"
class MascaraEspecial :
    public Mascara
{
public:
    MascaraEspecial();
};

