#pragma once
#include "Tela.h"
#include "Fase.h"
#include "InputTexto.h"
class TelaJogo :
    public Tela
{
public:
    TelaJogo();
    ~TelaJogo() {};
    void executar(Player* p, string nomes[5], long scorelist[5], ArrayList<Usuario> *uc);
    bool isDia();
    void setDia();
    long getScore();
    void setScore(int s);
protected:
    InputTexto nomejogador;
    bool podeinserirnome = false;
    bool estaPausado = false;
    bool dia = true;
    bool emlevelup = false;
    long score = 0;
    Fase *fase = nullptr;
    int indexfaseatual = 0;
};