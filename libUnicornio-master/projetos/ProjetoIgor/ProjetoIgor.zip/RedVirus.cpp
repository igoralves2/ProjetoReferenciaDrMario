#include "RedVirus.h"

RedVirus::RedVirus()
{
	setClasseVirus(1);
	setSprite("redvirus");
	setFeverPower(2);
	setChillPower(2);
	setCoughPower(1);
	setSneezePower(2);
	setAcuracy(2);
}
