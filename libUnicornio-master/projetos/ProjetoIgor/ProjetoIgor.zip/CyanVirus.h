#pragma once
#include "Virus.h"
class CyanVirus :
    public Virus
{
public:
    CyanVirus();
};

