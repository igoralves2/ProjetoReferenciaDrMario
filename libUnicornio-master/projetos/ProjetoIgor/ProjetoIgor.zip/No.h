#pragma once

template<class T>
class No {
public:
	No();
	~No();
	void defineDado(T novodado);
	void defineProximo(No* novoproximo);
	T getDado();
	No<T>* getProximo();
protected:
	No<T>* proximo;
	T dado;
};

template<class T>
inline No<T>::No() {
	//proximo = nullptr;
}

template<class T>
inline No<T>::~No()
{
}

template<class T>
inline void No<T>::defineDado(T novodado) {
	this->dado = novodado;
}

template<class T>
inline void No<T>::defineProximo(No* proximo) {
	this->proximo = proximo;
}

template<class T>
inline T No<T>::getDado() {
	return this->dado;
}

template<class T>
inline No<T>* No<T>::getProximo() {
	return this->proximo;
}
