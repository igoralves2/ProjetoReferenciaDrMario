#pragma once
#include "Player.h"
#include <string>
class Usuario
{
public:
	Usuario();
	Usuario(string novousuario, string novasenha);
	~Usuario();
	Player getPlayer();
	string getName();
	string getPassword();
	long getScore();
	void setScore(long s);
protected:
	Player p;
	string name;
	string password;
	long score;
};

