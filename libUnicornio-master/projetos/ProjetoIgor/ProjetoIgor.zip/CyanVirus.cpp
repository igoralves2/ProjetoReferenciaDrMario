#include "CyanVirus.h"

CyanVirus::CyanVirus()
{
	setClasseVirus(4);
	setSprite("cyanvirus");
	setFeverPower(5);
	setChillPower(4);
	setCoughPower(4);
	setSneezePower(4);
	setAcuracy(6);
}
