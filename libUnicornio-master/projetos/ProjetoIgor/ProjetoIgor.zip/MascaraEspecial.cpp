#include "MascaraEspecial.h"

MascaraEspecial::MascaraEspecial()
{
	setTipo(2);
	setEficienciaContagio(0.25f);
}
