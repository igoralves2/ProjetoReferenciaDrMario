#pragma once
#include "Virus.h"
class RedVirus :
    public Virus
{
    public:
        RedVirus();
};

