#pragma once
#include "Virus.h"
class BlueVirus :
    public Virus
{
public:
    BlueVirus();
};

