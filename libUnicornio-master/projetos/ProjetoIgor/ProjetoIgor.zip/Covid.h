#pragma once
#include "Virus.h"
class Covid :
    public Virus
{
public:
    Covid();
};

