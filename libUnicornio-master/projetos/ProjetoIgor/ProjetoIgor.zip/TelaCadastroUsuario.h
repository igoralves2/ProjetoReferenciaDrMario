#pragma once
#include "Tela.h"
#include "InputTexto.h"
class TelaCadastroUsuario :
    public Tela
{
public:
    TelaCadastroUsuario();
    ~TelaCadastroUsuario() {};
    void executar(Player *p, string nomes[5], long scorelist[5], ArrayList<Usuario> *uc);
protected:
    InputTexto username;
    InputTexto userPassword;
    int textoatual = 0;
};

