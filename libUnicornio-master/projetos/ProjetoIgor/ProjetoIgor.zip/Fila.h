#pragma once
#include "No.h"
template <class T>
class Fila {
public:
	Fila();
	~Fila();
	int quantidadeElementos();
	void enfileirar(T dado);
	void desenfileirar();
	bool estaVazia();
	T primeiroDaFila();
	T ultimoDaFila();
protected:
	No<T>* primeiroFila();
	No<T>* ultimoFila();
	No<T>* inicio;
	No<T>* fim;
	int count;
};

template<class T>
inline Fila<T>::Fila()
{
	inicio = nullptr;
	fim = nullptr;
	count = 0;
}

template<class T>
inline Fila<T>::~Fila()
{
}

template<class T>
inline No<T>* Fila<T>::primeiroFila()
{
	return inicio;
}

template<class T>
inline No<T>* Fila<T>::ultimoFila()
{
	return fim;
}

template<class T>
inline int Fila<T>::quantidadeElementos() {
	return count;
}

template<class T>
inline bool Fila<T>::estaVazia() {
	return count == 0;
}

template<class T>
inline void Fila<T>::enfileirar(T dado) {
	No<T>* novo = new No<T>;
	novo->defineDado(dado);
	if (estaVazia()) {
		inicio = novo;
		fim = novo;
	}
	else {
		fim->defineProximo(novo);
		fim = novo;
	}
	count++;
}

template<class T>
inline void Fila<T>::desenfileirar() {
	if (!estaVazia()) {
		if (count == 1) {
			inicio = nullptr;
			fim = nullptr;
		}
		else {
			No<T>* aux = inicio;
			inicio = inicio->getProximo();
			delete aux;
		}
		count--;
	}
}

template <class T>
inline T Fila<T>::primeiroDaFila() {
	return inicio->getDado();
}


template <class T>
inline T Fila<T>::ultimoDaFila() {
	return fim->getDado();
}