#include "Covid.h"

Covid::Covid()
{
	setClasseVirus(8);
	setSprite("covid");
	setFeverPower(7);
	setChillPower(9);
	setCoughPower(8);
	setSneezePower(10);
	setAcuracy(10);
}
