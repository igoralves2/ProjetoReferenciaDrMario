#include "MascaraNormal.h"

MascaraNormal::MascaraNormal()
{
	setTipo(1);
	setEficienciaContagio(0.5f);
}
