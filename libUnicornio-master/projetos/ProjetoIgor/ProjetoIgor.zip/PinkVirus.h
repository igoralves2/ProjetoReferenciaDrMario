#pragma once
#include "Virus.h"
class PinkVirus :
    public Virus
{
public:
    PinkVirus();
};

