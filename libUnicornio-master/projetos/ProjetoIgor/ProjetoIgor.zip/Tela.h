#pragma once
#include "libUnicornio.h"
#include "Player.h"
#include <string>
#include "Usuario.h"
#include "ArrayList.h"
class Tela
{
public:
	Tela();
	~Tela();
	virtual void executar(Player* p, string nomes[5], long scorelist[5], ArrayList<Usuario>* uc);
	int getTipo();
	void setTipo(int nro);
	bool isQuit();
	void troca();
protected:
	Texto t;
	bool habilitado = true;
	bool saiu = false;
	int tipo;
};