#pragma once
#include "Virus.h"
class PurpleVirus :
    public Virus
{
public:
    PurpleVirus();
};

