#include "YellowVirus.h"

YellowVirus::YellowVirus()
{
	setClasseVirus(2);
	setSprite("yellowvirus");
	setFeverPower(3);
	setChillPower(2);
	setCoughPower(2);
	setSneezePower(1);
	setAcuracy(2);
}
