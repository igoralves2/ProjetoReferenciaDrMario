#pragma once
#include "Tela.h"
class TelaRanking :
    public Tela
{
public:
    TelaRanking();
    ~TelaRanking() {};
    void executar(Player *p, string nomes[5], long scorelist[5], ArrayList<Usuario>* uc);
};

