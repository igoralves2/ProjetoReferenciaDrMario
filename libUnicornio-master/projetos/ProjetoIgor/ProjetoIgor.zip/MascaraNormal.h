#pragma once
#include "Mascara.h"
class MascaraNormal :
    public Mascara
{
public:
    MascaraNormal();
};

