#pragma once
using namespace std;
template<class E>
class ArrayList {

	//void adicionar(E e);
	//void remover();
	//E get(int index);
	//E get();
	//void show();
public:
	ArrayList();

	~ArrayList();


	void adicionar(E e);

	void remover();

	E get(int index);

	E get();

	void show();
	int size();
protected:
	E* vetor;
	int tamanho = 0;
	int nroElementos = 0;
	void realocar();


};
template <class E>
inline ArrayList<E>::ArrayList() {
	//indice = 0;
	tamanho = 3;
	nroElementos = 0;
	vetor = new E[3];
}
template <class E>
inline ArrayList<E>::~ArrayList() {

}

template <class E>
inline void ArrayList<E>::adicionar(E e) {
	if (nroElementos == tamanho) {
		realocar();
	}
	vetor[nroElementos] = e;
	nroElementos++;
}

template <class E>
inline void ArrayList<E>::remover() {
	if (nroElementos == 0) {
		std::cout << "Erro" << std::endl;
	}
	else {
		delete vetor[nroElementos];
		nroElementos--;
	}
}

template <class E>
inline E ArrayList<E>::get(int index) {
	if (index < 0 || index >= nroElementos) {
		std::cout << "Erro" << std::endl;
	}
	else {
		return vetor[index];
	}
}
template <class E>
inline E ArrayList<E>::get() {
	if (nroElementos == 0) {
		std::cout << "Vazio" << std::endl;
	}
	else {
		return vetor[nroElementos - 1];
	}
}
template <class E>
inline void ArrayList<E>::show() {
	if (this->nroElementos == 0) {
		std::cout << "Vazio" << std::endl;
	}
	else {
		for (int i = 0; i < nroElementos; i++) {
			std::cout << "v[" << i << "] = " << vetor[i] << std::endl;
		}
	}
}

template <class E>
inline void ArrayList<E>::realocar() {
	E* aux = new E[tamanho + 3];
	for (int i = 0; i < nroElementos; i++) {
		aux[i] = vetor[i];
	}
	vetor = aux;
	tamanho += 3;
	delete aux;
}

template<class E>
inline int ArrayList<E>::size()
{
	return nroElementos;
}
