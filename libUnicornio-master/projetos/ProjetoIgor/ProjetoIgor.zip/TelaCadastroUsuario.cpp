
#include "TelaCadastroUsuario.h"

TelaCadastroUsuario::TelaCadastroUsuario()
{
    setTipo(2);
    t.setFonte("supermario256");
    t.setCor(0, 0, 0);
    t.setString("Register your name and password:\n");
    t.setEscalaX(1);
    t.setEscalaY(1);
    t.setAlinhamento(TEXTO_CENTRALIZADO);
    textoatual = 0;
    username.inicializar();
}

void TelaCadastroUsuario::executar(Player* p, string nomes[5], long scorelist[5], ArrayList<Usuario> *uc)
{
    if (saiu) {
        textoatual = 0;
        username.inicializar();
        saiu = false;
    }
    else {
        t.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 4);
        if (textoatual == 0) {
            username.atualizar();
            Texto t2;
            t2.setFonte("supermario256");
            t2.setCor(0, 0, 0);
            t2.setString("Usuario:");
            t2.setEscalaX(1);
            t2.setEscalaY(1);
            t2.setAlinhamento(TEXTO_CENTRALIZADO);
            t2.desenhar(gJanela.getLargura() / 4, gJanela.getAltura() / 2);
            username.desenhar(gJanela.getLargura() * 3 / 4, gJanela.getAltura() / 2);
            if (gTeclado.pressionou[TECLA_ENTER]) {
                textoatual++;
                username.finalizar();
                userPassword.inicializar();
            }
        }
        else if (textoatual == 1) {

            userPassword.atualizar();
            Texto t3;
            t3.setFonte("supermario256");
            t3.setCor(0, 0, 0);
            t3.setString("Senha");
            t3.setEscalaX(1);
            t3.setEscalaY(1);
            t3.setAlinhamento(TEXTO_CENTRALIZADO);
            t3.desenhar(gJanela.getLargura() / 4, gJanela.getAltura() / 2 + 20);
            userPassword.desenhar(gJanela.getLargura() * 3 / 4, gJanela.getAltura() / 2 + 20);
            if (gTeclado.pressionou[TECLA_ENTER]) {
                bool achounalista = false;
                int i = 0;
                for (i; i < (*uc).size(); i++) {
                    if (uc->get(i).getName() == username.getString()) {
                        achounalista = true;
                        break;
                    }
                }
                if (achounalista) {
                    if (uc->get(i).getPassword() == userPassword.getString()) {
                        Usuario u = Usuario((*uc).get(i).getName(), (*uc).get(i).getPassword());
                        uc->adicionar(u);
                        userPassword.finalizar();
                        textoatual++;
                    }
                    else {
                        textoatual = 0;
                        userPassword.finalizar();
                        username.inicializar();
                    }
                }
                else {
                    Usuario u = Usuario((*uc).get(i).getName(), (*uc).get(i).getPassword());
                    uc->adicionar(u);
                    userPassword.finalizar();
                    textoatual++;
                }
            }
        }
        else if (textoatual == 2) {
            Texto result;
            result.setFonte("supermario256");
            result.setCor(0, 0, 0);
            result.setString("Registrado com sucesso! pressione ENTER para continuar");
            result.setEscalaX(1);
            result.setEscalaY(1);
            result.setAlinhamento(TEXTO_CENTRALIZADO);
            result.desenhar(gJanela.getLargura() / 2, gJanela.getAltura() / 2 + 30);
            if (gTeclado.pressionou[TECLA_ENTER]) {
                saiu = true;
            }
        }
    }
}
