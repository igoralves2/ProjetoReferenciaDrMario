#include "GreenVirus.h"

GreenVirus::GreenVirus()
{
	setClasseVirus(3);
	setSprite("greenvirus");
	setFeverPower(4);
	setChillPower(3);
	setCoughPower(3);
	setSneezePower(3);
	setAcuracy(4);
}
