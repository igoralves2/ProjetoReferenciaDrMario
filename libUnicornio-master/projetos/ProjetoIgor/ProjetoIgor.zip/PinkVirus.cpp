#include "PinkVirus.h"

PinkVirus::PinkVirus()
{
	setClasseVirus(7);
	setSprite("pinkvirus");
	setFeverPower(9);
	setChillPower(8);
	setCoughPower(14);
	setSneezePower(7);
	setAcuracy(10);
}
