#pragma once
#include "Virus.h"
class GreenVirus :
    public Virus
{
public:
    GreenVirus();
};

