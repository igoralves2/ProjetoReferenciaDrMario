#pragma once
#include "Virus.h"
class YellowVirus :
    public Virus
{
public:
    YellowVirus();
};

