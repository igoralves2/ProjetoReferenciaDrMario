#pragma once
#include "libUnicornio.h"
#include "Tela.h"
class TelaPrincipal :
    public Tela
{
public:
    TelaPrincipal();
    ~TelaPrincipal() {};
    void executar(Player *p, string nomes[5], long scorelist[5], ArrayList<Usuario>* uc);
};

