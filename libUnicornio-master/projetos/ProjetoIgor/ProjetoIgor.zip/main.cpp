#include "Jogo.h"
#include "Fila.h"
using namespace std;

int main(int argc, char* argv[])
{
	Jogo jogo;
	jogo.inicializar();
	jogo.executar();
	jogo.finalizar();
	return 0;
}
